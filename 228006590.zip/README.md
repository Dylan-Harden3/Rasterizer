# CSCE-441-A1
Dylan Harden, 228006590, dylanharden3@tamu.edu
All 7 Tasks Completed
Code from https://stackoverflow.com/questions/2049582/how-to-determine-if-a-point-is-in-a-2d-triangle was used to compute if a point was in a triangle
